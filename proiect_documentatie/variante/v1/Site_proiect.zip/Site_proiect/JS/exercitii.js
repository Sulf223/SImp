// Exerciții inspirate din codurile de sortare C++

var exercitii = [
    {
        titlu: "Bubble sort – condiția din if",
        text: "Completează condiția astfel încât vectorul să fie sortat crescător.",
        cod: [
            "for (int i = 0; i < n - 1; i++) {",
            "    if ( ____ ) {",
            "        int aux = v[i];",
            "        v[i] = v[i + 1];",
            "        v[i + 1] = aux;",
            "    }",
            "}"
        ],
        raspunsuri: ["v[i] > v[i + 1]"]
    },
    {
        titlu: "Sortare prin inserție – condiția din while",
        text: "Completează condiția pentru a muta elementele mai mari spre dreapta.",
        cod: [
            "for (int i = 1; i < n; i++) {",
            "    int key = v[i];",
            "    int j = i - 1;",
            "    while ( ____ ) {",
            "        v[j + 1] = v[j];",
            "        j--;",
            "    }",
            "    v[j + 1] = key;",
            "}"
        ],
        raspunsuri: ["j >= 0 && v[j] > key"]
    }
];

var indexCurent = 0;

function afiseazaExercitiu() {
    var ex = exercitii[indexCurent];
    var container = document.getElementById("exercitiu-container");
    if (!container) return;

    var html = "<h3>" + ex.titlu + "</h3>";
    html += "<p>" + ex.text + "</p>";
    html += "<pre><code>";

    for (var i = 0; i < ex.cod.length; i++) {
        var linie = ex.cod[i];
        if (linie.indexOf("____") !== -1) {
            html += linie.replace("____",
                "<input type='text' id='raspuns" + i + "' size='30'>"
            ) + "\n";
        } else {
            html += linie + "\n";
        }
    }

    html += "</code></pre>";
    container.innerHTML = html;
}

function verificaExercitiu() {
    var ex = exercitii[indexCurent];
    var corect = true;
    var mesaj = "";

    for (var i = 0; i < ex.cod.length; i++) {
        if (ex.cod[i].indexOf("____") !== -1) {
            var userInput = document.getElementById("raspuns" + i).value.trim();
            var raspCorect = ex.raspunsuri[0];
            if (userInput === raspCorect) {
                mesaj = "Bravo, răspuns corect!";
            } else {
                mesaj = "Răspuns greșit. Încearcă din nou.";
                corect = false;
            }
        }
    }

    document.getElementById("feedback").innerText = mesaj;
}

function urmatorulExercitiu() {
    indexCurent++;
    if (indexCurent >= exercitii.length) {
        indexCurent = 0;
    }
    document.getElementById("feedback").innerText = "";
    afiseazaExercitiu();
}

window.addEventListener("load", afiseazaExercitiu);
