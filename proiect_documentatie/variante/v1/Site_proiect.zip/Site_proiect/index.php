<?php
// index.php
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Portal C++ – Metode de sortare</title>
    <link rel="stylesheet" href="stil.css">
</head>
<body>
<header>
    <h1>Portal C++ – Metode de sortare</h1>
    <p>Exemple, coduri din laborator și exerciții interactive (tip W3Schools)</p>
</header>

<nav>
    <ul>
        <li><a href="index.php">Acasă</a></li>
        <li><a href="php/lista_metode.php">Metode de sortare (BD)</a></li>
        <li><a href="php/lista_exercitii.php">Exerciții C++</a></li>
        <li><a href="php/compilator_online.php">Compilator C++ online</a></li>
        <li><a href="frames.html">Exemplu frame-uri</a></li>
    </ul>
</nav>

<main>
    <h2>Introducere</h2>
    <p>
        Acest portal prezintă principalele <strong>metode de sortare</strong> studiate la C++:
        Bubble sort, sortare prin inserție, interclasare, QuickSort etc.
        Codurile sunt preluate din arhiva „metode de sortare” și organizate într-o bază de date,
        iar utilizatorul poate exersa completând bucăți lipsă de cod, în stilul W3Schools.
    </p>

    <h3>Ce poți face pe acest site:</h3>
    <ul>
        <li>Vezi lista metodelor de sortare, cu descrieri și link către fișierele C++ originale.</li>
        <li>Rezolvi exerciții interactive de completare a codului C++.</li>
        <li>Testezi cod C++ direct în pagină, folosind un compilator online integrat.</li>
        <li>Vezi un exemplu de pagină cu frame-uri (pentru cerințele de proiect).</li>
    </ul>

    <h3>Exemplu tabel comparativ</h3>
    <table>
        <tr><th>Metodă</th><th>Complexitate (medie)</th><th>Tip</th></tr>
        <tr><td>Bubble sort</td><td>O(n²)</td><td>simplă</td></tr>
        <tr><td>QuickSort</td><td>O(n log n)</td><td>eficientă</td></tr>
    </table>
</main>

<footer>
    <p>&copy; 2025 Portal C++ – Metode de sortare</p>
</footer>
</body>
</html>
